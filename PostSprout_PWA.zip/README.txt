# PostSprout

This folder contains the current PostSprout app packaged as a Progressive Web App (PWA).

## Files
- `index.html` — the app
- `manifest.json` — installable app metadata
- `service-worker.js` — caches the app shell for repeat/offline opening
- `icon.svg` — app icon

## Publish with GitHub Pages
1. Upload **all four files** to the root of the existing public `postsprout` repository.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select branch `main` and folder `/(root)`, then save.
5. Wait for the Pages deployment to finish. The site URL should be shown on the Pages settings screen.

## Important AI note
The current app's content suggestions are rule-based, not real AI. To add real AI, connect the frontend to a secure backend endpoint. Never put a Gemini/API key in `index.html` or any public repository. This package does not claim AI is connected yet.
